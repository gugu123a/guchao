# Private Brand Assets

This folder contains the original embedded brand-related snippets extracted from the private build, plus the font and text replacement material removed from public builds.

Keep this separate from the public repository unless you have rights to publish those assets. The public packages use placeholders and do not require this folder to run.
