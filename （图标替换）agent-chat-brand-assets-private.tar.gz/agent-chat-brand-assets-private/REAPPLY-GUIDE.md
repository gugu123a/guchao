# Private Asset Reapply Guide

This private package contains the brand-related snippets removed from the public packages. Keep it separate from the public repository unless you have rights to redistribute every asset inside it.

## Files

- `brand-snippets.html`: original SVG symbols, sidebar wordmark, and animated status sprite source.
- `brand-fonts.css`: original embedded `@font-face` blocks and brand font stack variables removed from public builds.
- `replacement-map.json`: neutral public copy mapped back to the original private copy.

## Public placeholders to replace

- Replace `<symbol id="claude-mark">` in `static/index.html` or demo `index.html` with the `main symbol` snippet.
- Replace `<symbol id="claude-spinner-mark">` with the `spinner symbol` snippet.
- Replace the `.mobile-sidebar-title` text node with the `sidebar wordmark` snippet.
- Replace the generic `CLAUDE_LOGO_SPRITES` block with the `sprite set` snippet.
- Paste `brand-fonts.css` into the top of the main `<style>` block if you have rights to use those fonts.
- Restore private copy using `replacement-map.json` only when you have rights to use the relevant names.

The public package is designed to work without any of these private snippets.
